using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


namespace SeleniumTests
{
    [TestClass]
    public class CP06RadioButtons
    {
        private static IWebDriver driver;
        
        [ClassInitialize]
        public static void InitializeClass(TestContext testContext)
        { 
            driver = new ChromeDriver();
        }
        
        [ClassCleanup]
        public static void CleanupClass()
        {
            try
            {
                //driver.Quit();// quit does not close the window
                driver.Close();
                driver.Dispose();
            }
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }
        

        [TestMethod]
        public void TheCP06RadioButtonsTest()
        {   
            // Abre el formulario
            driver.Navigate().GoToUrl("https://docs.google.com/forms/d/e/1FAIpQLSeLqx5UUpNwRN5g6UmT_IUhleG1r_dwDtmAC-yGL0OdhqKZ1Q/viewform");

            // Resetea el Formulario
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[3]/div/div[3]/div/span/span")).Click();
            Thread.Sleep(300);
            driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='Cancelar'])[2]/following::span[2]")).Click();

            // Selecciona NO
            driver.FindElement(By.XPath("//div[@id='i8']/div[3]/div")).Click();
            Thread.Sleep(300);
            // Comprueba que NO est� marcado y SI no lo est�
            Assert.AreEqual(0, driver.FindElements(By.CssSelector("div[id=i5].isChecked")).Count);
            Assert.AreEqual(1, driver.FindElements(By.CssSelector("div[id=i8].isChecked")).Count);

            // Selecciona SI
            driver.FindElement(By.XPath("//div[@id='i5']/div[3]/div")).Click();
            // Comprueba que SI est� marcado y NO no lo est�
            Thread.Sleep(300);
            Assert.AreEqual(1, driver.FindElements(By.CssSelector("div[id=i5].isChecked")).Count);
            Assert.AreEqual(0, driver.FindElements(By.CssSelector("div[id=i8].isChecked")).Count);
            // Pulsa siguiente / Cambio de p�gina
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[3]/div/div/div/span/span")).Click();

            // Comprueba que no haya ning�n Radio Button Marcado
            Assert.AreEqual(0, driver.FindElements(By.CssSelector("div.isChecked")).Count);

            // Clicka varias veces los Radio Buttons de cada fila
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[2]/div/div/div[2]/div/span/div/label[2]/div[2]/div/div/div[3]")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[2]/div/div/div[2]/div/span/div/label[5]/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[2]/div/div/div[2]/div/span/div/label[9]/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[2]/span/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[2]/span/div[5]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[4]/span/div[3]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[4]/span/div[6]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[6]/span/div[4]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[6]/span/div[3]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[8]/span/div[3]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[8]/span/div[5]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[10]/span/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[10]/span/div[6]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[12]/span/div[5]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[12]/span/div[3]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[12]/span/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[14]/span/div[2]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[14]/span/div[3]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[14]/span/div[4]/div/div/div[3]/div")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[14]/span/div[5]/div/div/div[3]")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div/div/div[14]/span/div[6]/div/div/div[3]/div")).Click();
            Thread.Sleep(300);
            // Comrpueba que solo haya 8 radio buttons marcados en esta p�gina
            Assert.AreEqual(8, driver.FindElements(By.CssSelector("div.isChecked")).Count);

            // Env�a el formulario
            driver.FindElement(By.XPath("//div[@id='i10']/div[2]")).Click();
            driver.FindElement(By.XPath("//form[@id='mG61Hd']/div[2]/div/div[3]/div/div/div[2]/span")).Click();
 
        }

    }
}
